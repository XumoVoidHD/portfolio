"use client"

import { useInView } from "react-intersection-observer"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export function Projects() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  const projects = [
    {
      title: "Project One",
      description: "A web application built with React and Node.js that helps users manage their tasks efficiently.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["React", "Node.js", "MongoDB"],
      liveLink: "#",
      githubLink: "#",
    },
    {
      title: "Project Two",
      description: "An e-commerce platform with a seamless checkout process and inventory management system.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["Next.js", "Stripe", "Tailwind CSS"],
      liveLink: "#",
      githubLink: "#",
    },
    {
      title: "Project Three",
      description: "A mobile-responsive dashboard that visualizes data with interactive charts and graphs.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["TypeScript", "D3.js", "Firebase"],
      liveLink: "#",
      githubLink: "#",
    },
  ]

  return (
    <section id="projects" className="py-16 md:py-24">
      <div className="container" ref={ref}>
        <h2 className="text-3xl md:text-5xl font-bold text-center mb-16">
          My <span className="gradient-text">Projects</span>
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              className={`overflow-hidden flex flex-col h-full card-hover transition-all duration-700 delay-${index * 100} ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
            >
              <div className="relative h-48 w-full overflow-hidden group">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-primary/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Link
                    href={project.liveLink}
                    className="bg-white text-primary rounded-full p-2 mx-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                  >
                    <ExternalLink className="h-5 w-5" />
                  </Link>
                  <Link
                    href={project.githubLink}
                    className="bg-white text-primary rounded-full p-2 mx-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75"
                  >
                    <Github className="h-5 w-5" />
                  </Link>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl">{project.title}</CardTitle>
                <CardDescription className="line-clamp-2">{project.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex gap-4 mt-auto">
                <Button variant="outline" size="sm" className="rounded-full" asChild>
                  <Link href={project.githubLink} className="flex items-center gap-2">
                    <Github className="h-4 w-4" />
                    Code
                  </Link>
                </Button>
                <Button size="sm" className="rounded-full" asChild>
                  <Link href={project.liveLink} className="flex items-center gap-2">
                    <ExternalLink className="h-4 w-4" />
                    Live Demo
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

