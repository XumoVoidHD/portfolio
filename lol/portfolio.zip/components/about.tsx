"use client"
import { Button } from "@/components/ui/button"
import { FileText } from "lucide-react"
import Image from "next/image"
import { useInView } from "react-intersection-observer"

export function About() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  return (
    <section id="about" className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-primary/5 section-pattern"></div>
      <div className="container relative z-10" ref={ref}>
        <h2 className="text-3xl md:text-5xl font-bold text-center mb-16">
          About <span className="gradient-text">Me</span>
        </h2>
        <div
          className={`grid md:grid-cols-2 gap-12 items-center transition-all duration-700 ${inView ? "opacity-100" : "opacity-0 translate-y-10"}`}
        >
          <div className="flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-primary/20 shadow-xl shadow-primary/10 transition-transform hover:scale-105 duration-300">
              <Image src="/placeholder.svg?height=320&width=320" alt="Your Name" fill className="object-cover" />
            </div>
          </div>
          <div>
            <p className="text-lg mb-6 leading-relaxed">
              Hello! I'm a passionate developer with a strong foundation in web development. I enjoy creating elegant
              solutions to complex problems and am dedicated to crafting intuitive, user-friendly experiences.
            </p>
            <p className="text-lg mb-8 leading-relaxed">
              With expertise in modern frameworks and a keen eye for design, I strive to build applications that are not
              only functional but also aesthetically pleasing and accessible.
            </p>
            <Button className="flex items-center gap-2 rounded-full px-6 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
              <FileText className="h-4 w-4" />
              Download Resume
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

