"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section className="relative py-20 md:py-32 overflow-hidden hero-gradient">
      <div className="absolute inset-0 section-pattern opacity-30"></div>
      <div className="container flex flex-col items-center text-center relative z-10">
        <div
          className={cn(
            "opacity-0 translate-y-4 transition-all duration-700",
            isVisible && "opacity-100 translate-y-0",
          )}
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
            Hi, I'm <span className="gradient-text">Your Name</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            I'm a passionate developer specializing in building exceptional digital experiences.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="rounded-full px-8 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
              asChild
            >
              <Link href="#projects">View My Work</Link>
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-8 border-2 hover:bg-primary/5" asChild>
              <Link href="#contact">Contact Me</Link>
            </Button>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce hidden md:block">
          <Link
            href="#about"
            className="p-2 rounded-full bg-background/80 shadow-md hover:bg-background transition-colors"
          >
            <ArrowDown className="h-6 w-6 text-primary" />
          </Link>
        </div>
      </div>
    </section>
  )
}

