"use client"

import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Code, Database, Layout, Palette, Server, Smartphone } from "lucide-react"

export function Skills() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  const skillCategories = [
    {
      title: "Frontend Development",
      icon: <Layout className="h-8 w-8 text-primary" />,
      skills: ["HTML/CSS", "JavaScript", "React", "Next.js", "Tailwind CSS"],
    },
    {
      title: "Backend Development",
      icon: <Server className="h-8 w-8 text-primary" />,
      skills: ["Node.js", "Express", "Python", "Django", "RESTful APIs"],
    },
    {
      title: "Database",
      icon: <Database className="h-8 w-8 text-primary" />,
      skills: ["MongoDB", "PostgreSQL", "MySQL", "Firebase", "Redis"],
    },
    {
      title: "UI/UX Design",
      icon: <Palette className="h-8 w-8 text-primary" />,
      skills: ["Figma", "Adobe XD", "Responsive Design", "Wireframing", "Prototyping"],
    },
    {
      title: "Mobile Development",
      icon: <Smartphone className="h-8 w-8 text-primary" />,
      skills: ["React Native", "Flutter", "iOS", "Android", "Progressive Web Apps"],
    },
    {
      title: "Other",
      icon: <Code className="h-8 w-8 text-primary" />,
      skills: ["Git", "Docker", "CI/CD", "Testing", "AWS"],
    },
  ]

  return (
    <section id="skills" className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-primary/5 section-pattern"></div>
      <div className="container relative z-10" ref={ref}>
        <h2 className="text-3xl md:text-5xl font-bold text-center mb-16">
          My <span className="gradient-text">Skills</span>
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <Card
              key={index}
              className={`overflow-hidden card-hover bg-background/80 backdrop-blur-sm transition-all duration-700 delay-${index * 100} ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 rounded-full bg-primary/10">{category.icon}</div>
                  <h3 className="text-xl font-semibold">{category.title}</h3>
                </div>
                <ul className="space-y-3">
                  {category.skills.map((skill, skillIndex) => (
                    <li key={skillIndex} className="flex items-center gap-3">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span className="font-medium">{skill}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

